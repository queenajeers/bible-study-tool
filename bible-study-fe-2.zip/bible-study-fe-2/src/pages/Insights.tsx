export default function Insights() {
  return <div>Insights</div>;
}
